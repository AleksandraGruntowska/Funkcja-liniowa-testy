﻿using System;

namespace funkcja_liniowa
{
    class Program
    {
        static void Main(string[] args)
        {
            funkcja.intro();
            funkcja.pobierzDane();
            if(funkcja.sprawdzenie())
            {
                Console.WriteLine("Dany punkt lezy na prostej");
            }
            else
            {
                Console.WriteLine("Dany punkt NIE lezy na prostej");
            }
        }
    }
}
