﻿using System;
using System.Collections.Generic;
using System.Text;

namespace funkcja_liniowa
{
    static public class funkcja
    {
        //pola
        static public double a=0.5, b=10;
        static public double punktX,punktY;
        //metoda wyswietlajaca przeznaczenie programu
        static public void intro()
        {
            Console.WriteLine("Sprawdzenie czy punkt lezy na prostej y=0,5x-10" +
                "\nPodaj wspolrzedne punktu w formacie [x=wartosc;y=wartosc]");
        }
        //pobranie danych od uzytkownika w formacie [x=wartosc;y=wartosc]
        static public void pobierzDane()
        {
            //rozbicie tekstu na zmienne
            string dane;
            string [] rodzielone;
            dane = Console.ReadLine();
            rodzielone = dane.Split("x=");
            dane = "";
            for (int i=0;i< rodzielone.Length;i++)
            {
                dane += rodzielone[i];
            }

            rodzielone = dane.Split("y=");
            dane = "";

            for (int i = 0; i < rodzielone.Length; i++)
            {
                dane += rodzielone[i];
            }
            rodzielone = dane.Split(';');
            punktX = double.Parse(rodzielone[0]);
            punktY = double.Parse(rodzielone[1]);
        }
        //metoda sprawdzajaca czy punkt znajduje sie na proscie zwraca true or false
        static public bool sprawdzenie()
        {
            if (punktY == (a*punktX-b))
            {
                
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
