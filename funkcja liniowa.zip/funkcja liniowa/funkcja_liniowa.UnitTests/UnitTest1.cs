using System;
using Xunit;
using funkcja_liniowa;

namespace funkcja_liniowa.UnitTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            funkcja.punktX = 1;
            funkcja.punktY = -9.5;
            bool wynik = funkcja.sprawdzenie();
            Assert.True(wynik);
        }
        [Fact]
        public void Test2()
        {
            funkcja.punktX = 2;
            funkcja.punktY = -9;
            bool wynik = funkcja.sprawdzenie();
            Assert.True(wynik);
        }
        [Fact]
        public void Test3()
        {
            funkcja.punktX = 20;
            funkcja.punktY = 0;
            bool wynik = funkcja.sprawdzenie();
            Assert.True(wynik);
        }
    }
}
